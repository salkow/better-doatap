## Xristos
* home page
* status bar
* footer
* backend
* qna
* επικοινωνια

## Antonis
* search bar
* search page
* login page
* profile 
* register
* κανε αιτηση
* οι αιτησεις μου
* admin 



## Other
πως κανω αιτηση

check if we can include every package we want, problem with css scope(child enherits parrent's css)


steps:
pip install pipenv
pipenv install -r requirements.txt
pipenv shell
python manage.py runserver